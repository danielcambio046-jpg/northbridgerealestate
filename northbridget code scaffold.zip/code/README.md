# NorthBridge Real Estate — Starter Scaffold

A real, runnable Next.js + Prisma app — not a mock. It implements Phase 0 of
the roadmap: data model, a server-rendered marketplace, a property detail
page with lead capture, and the normalized lead-entry API that later
automation (WhatsApp, Meta lead ads, n8n) plugs into.

## What's here

- `prisma/schema.prisma` — full data model (users with hashed passwords,
  properties with a unique `ticker` code, leads, CRM stages, AI agent audit
  log, documents, risk assessments, development projects).
- `prisma/seed.ts` — seeds the same 8 demo properties shown in the live chat
  prototype, so the deployed site isn't empty on day one.
- **Auth** — `lib/auth.ts` (NextAuth, credentials provider, JWT sessions),
  `/register` (choose Investor or Seller) and `/login` pages, `middleware.ts`
  protecting `/properties/new`.
- **Seller flow** — `/properties/new` is now a real form, not just an API
  endpoint. `POST /api/properties` reads the owner from the session instead
  of trusting a client-supplied `ownerId`, and only Seller/Agent/Developer/
  Admin accounts are allowed to use it.
- `app/page.tsx` — homepage with hero search and market hub cards.
- `app/properties/page.tsx` — server-rendered marketplace grid with filters.
- `app/properties/[id]/page.tsx` — property detail page with a lead form.
- `app/api/leads/route.ts` — normalized lead capture entry point used by
  every channel (web form today; WhatsApp/Meta webhooks later transform their
  payload into this same shape).
- `lib/ai/lead-qualification.ts` — deterministic-first lead scorer.

## What's intentionally NOT here yet

The AI Orchestrator service, n8n workflows, HubSpot sync, payments/escrow
(Stripe), e-signature (DocuSign), email verification, password reset, and
the full investor portal. Those need real provider accounts and secret keys
— they're the natural next layer now that accounts and listings are real.

## Deploy this for real (Vercel + Neon Postgres, both free tier)

**1. Push this code to GitHub.** Create an empty repo, then from this folder:
```bash
git init && git add . && git commit -m "NorthBridge scaffold"
git remote add origin <your-empty-github-repo-url>
git push -u origin main
```

**2. Create a free Postgres database on [Neon](https://neon.tech)** (Supabase
works the same way). Create a project, then copy the connection string it
gives you — it looks like
`postgresql://user:password@ep-xxxx.neon.tech/northbridge?sslmode=require`.

**3. Apply the schema to that database, from your own machine** (this
sandbox can't reach Prisma's binary host, so this step has to happen on a
machine with normal internet access):
```bash
npm install
DATABASE_URL="<your-neon-connection-string>" npx prisma migrate dev --name init
DATABASE_URL="<your-neon-connection-string>" npx prisma db seed
```
This creates `prisma/migrations/`, applies it to the database, and loads the
8 demo properties. Commit the new `prisma/migrations` folder and push it.

**4. Import the repo on [Vercel](https://vercel.com).** "Add New Project" →
select your GitHub repo → before deploying, open **Environment Variables**
and add:
- `DATABASE_URL` — the same Neon connection string.
- `NEXTAUTH_SECRET` — any long random string (`openssl rand -base64 32` locally).
- `NEXTAUTH_URL` — the production URL Vercel will give this project (you can
  add this one after the first deploy, then redeploy).

Deploy.

Vercel's build runs `prisma migrate deploy && next build` (already wired into
`package.json`), so every future push that includes a new migration gets
applied automatically — you won't need to repeat step 3 for schema changes,
only the first time.

**5. Visit the URL Vercel gives you.** Register an account choosing "I want
to list a property" to try the seller flow end to end: sign up → `/properties/new`
→ submit → it appears in `/properties` marked "Pending verification."
Register a second account choosing "I want to invest" to confirm it can
browse and send a lead, but is refused at `/properties/new`.

## What I could and couldn't verify from here

I rewrote the missing pieces this scaffold needed to actually build — a root
layout (Next.js requires one and there wasn't one), `tsconfig.json` path
aliases, the property detail page and lead form the listing page was already
linking to, the seed script, and the Vercel build wiring above. I syntax- and
import-checked every `.ts`/`.tsx` file in this repo with esbuild against the
real `tsconfig.json`, so cross-file imports and JSX are confirmed sound.

What I could not do from this sandbox: actually run `prisma generate` or
`next build` to completion, because Prisma downloads a native query engine
binary from `binaries.prisma.sh`, which this environment's network policy
blocks. That step works normally on Vercel and on your own machine — it's
only blocked here. Step 3 above is exactly that step, run somewhere it isn't
blocked.

## Suggested next step

Listings submitted through `/properties/new` go straight to
`PENDING_VERIFICATION` with no one able to flip them to `ACTIVE` yet — that's
the next real gap. A minimal admin view (list pending properties, a button
to approve/reject, restricted to the `ADMIN` role) closes the loop the live
chat prototype already showed with its "Mark verified" toggle, now backed by
the real database and real accounts.
